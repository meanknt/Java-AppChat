/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import javax.swing.*;

/**
 *
 * @author beaslzlo
 */
public class Test {
    private JFrame frm = new JFrame();
    private JTextArea tar = new JTextArea();
    
    public void draw(){
        frm.setSize(500, 300);
        frm.setVisible(true);
    }
    
    public static void main(String[] args) {
        new Test().draw();
    }
}
